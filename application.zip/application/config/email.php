<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config = array(

    'protocol' => 'smtp',
    'smtp_host' => 'smtp.mailtrap.io',
    'smtp_port' => 2525,
    'smtp_user' => 'f08696f5a23969',
    'smtp_pass' => '77d5c9f8a919c7',
    'crlf' => "\r\n",
    'newline' => "\r\n",

    // 'protocol' => 'smtp', // 'mail', 'sendmail', or 'smtp'
    // 'smtp_host' => 'ssl/smtp.gmail.com', 
    // 'smtp_port' => 465,
    // 'smtp_user' => 'daramolaadekunle15@gmail.com',
    // 'smtp_pass' => 'emmanuel1992',
    // 'smtp_crypto' => 'tls', //can be 'ssl' or 'tls' for example
    // 'mailtype' => 'html', //plaintext 'text' mails or 'html'
    // 'newline'=>'\r\n',
    // 'smtp_timeout' => '4', //in seconds
    // 'charset' => 'utf-8',
    // 'wordwrap' => TRUE
);