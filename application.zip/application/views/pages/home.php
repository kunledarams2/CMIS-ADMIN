<h4><?=$title ?></h4>
<p>Welcome to NYC Academy Blog..........</p>
